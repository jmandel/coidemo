import { DB } from '../src/db';

const db = new DB();
db.init();

// Example cohort; replace with real users or connect to roster sync.
const now = new Date().toISOString();

const sampleUsers = [
  { hl7_id: 'hl7|1', name: 'Jane Doe', email: 'jane.doe@example.org', org_role: 'Board', is_admin: 1, is_discloser: 1 },
  { hl7_id: 'hl7|2', name: 'John Smith', email: 'john.smith@example.org', org_role: 'TSC', is_admin: 0, is_discloser: 1 },
  { hl7_id: 'hl7|3', name: 'Ava Liu', email: 'ava.liu@example.org', org_role: 'ProductDirector', is_admin: 0, is_discloser: 1 }
];

for (const u of sampleUsers) {
  const created = db.createOrUpdateUser({ hl7_id: u.hl7_id, name: u.name, email: u.email, org_role: u.org_role as any });
  if (u.is_admin) db.setAdminByEmail(u.email);
  // create empty disclosure
  db.getOrCreateDisclosureForUser(created.id);
}

console.log('Seed complete. Users inserted:', sampleUsers.length);
