import { Database } from 'bun:sqlite';

export type User = {
  id: number;
  hl7_id: string;
  name: string;
  email: string;
  org_role: string;     // Board | Officer | Exec | TSC | ProductDirector | ProgramChair | CoChair
  is_admin: number;     // 0 or 1
  is_discloser: number; // 0 or 1
  created_at: string;
  updated_at: string;
};

export type Disclosure = {
  id: number;
  user_id: number;
  status: string; // Not Submitted | Submitted | Updated
  last_updated_ts: string;
};

export type DisclosureItem = {
  id: number;
  disclosure_id: number;
  type: 'employment' | 'ownership' | 'compensation' | 'travel_gift' | 'ip';
  entity_name: string | null;
  role_title: string | null;
  is_primary_employment: number;
  ownership_ge_one_percent: number;

  contracting_entity: string | null;
  ultimate_funder: string | null;
  is_nda: number;
  sector_type: string | null;
  topic_area: string | null;
  over_threshold_10k: number;

  ip_type: string | null;
  ip_title: string | null;
  ip_application_number: string | null;
  url: string | null;

  description: string | null;
  created_at: string;
  updated_at: string;
};

export class DB {
  db: Database;

  constructor(path = './data/app.db') {
    this.db = new Database(path);
    this.db.exec(`PRAGMA journal_mode=WAL;`);
  }

  init() {
    const schema = Bun.file('./src/schema.sql').text();
    this.db.exec(schema);
  }

  nowISO() {
    return new Date().toISOString();
  }

  // --- Users ---
  getUserByOIDC(hl7_id: string): User | null {
    const stmt = this.db.query(`SELECT * FROM users WHERE hl7_id = ?`);
    const row = stmt.get(hl7_id) as User | undefined;
    return row ?? null;
  }

  getUserById(id: number): User | null {
    const stmt = this.db.query(`SELECT * FROM users WHERE id = ?`);
    const row = stmt.get(id) as User | undefined;
    return row ?? null;
  }

  createOrUpdateUser(u: Partial<User> & { hl7_id: string; name: string; email: string; org_role?: string }): User {
    const existing = this.getUserByOIDC(u.hl7_id);
    const now = this.nowISO();
    if (existing) {
      const name = u.name ?? existing.name;
      const email = u.email ?? existing.email;
      const org_role = u.org_role ?? existing.org_role;
      const stmt = this.db.prepare(`UPDATE users SET name=?, email=?, org_role=?, updated_at=? WHERE id=?`);
      stmt.run(name, email, org_role, now, existing.id);
      return { ...existing, name, email, org_role, updated_at: now };
    } else {
      const org_role = u.org_role ?? 'TSC';
      const is_admin = 0;
      const is_discloser = 1;
      const stmt = this.db.prepare(
        `INSERT INTO users (hl7_id, name, email, org_role, is_admin, is_discloser, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      );
      stmt.run(u.hl7_id, u.name, u.email, org_role, is_admin, is_discloser, now, now);
      const id = this.db.query(`SELECT last_insert_rowid() as id`).get() as { id: number };
      return {
        id: id.id, hl7_id: u.hl7_id, name: u.name, email: u.email, org_role,
        is_admin, is_discloser, created_at: now, updated_at: now
      };
    }
  }

  setAdminByEmail(email: string) {
    const now = this.nowISO();
    const stmt = this.db.prepare(`UPDATE users SET is_admin=1, updated_at=? WHERE email=?`);
    stmt.run(now, email);
  }

  // --- Sessions ---
  createSession(user_id: number, session_id: string, expires_at_iso: string) {
    const now = this.nowISO();
    const stmt = this.db.prepare(
      `INSERT INTO sessions (session_id, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)`
    );
    stmt.run(session_id, user_id, expires_at_iso, now);
  }

  getSession(session_id: string) {
    const stmt = this.db.prepare(`SELECT * FROM sessions WHERE session_id = ?`);
    return stmt.get(session_id) as { id: number; session_id: string; user_id: number; expires_at: string; created_at: string } | undefined;
  }

  deleteSession(session_id: string) {
    const stmt = this.db.prepare(`DELETE FROM sessions WHERE session_id = ?`);
    stmt.run(session_id);
  }

  // --- Disclosures ---
  getOrCreateDisclosureForUser(user_id: number): Disclosure {
    const existing = this.db.query(`SELECT * FROM disclosures WHERE user_id = ?`).get(user_id) as Disclosure | undefined;
    if (existing) return existing;
    const now = this.nowISO();
    const stmt = this.db.prepare(`INSERT INTO disclosures (user_id, status, last_updated_ts) VALUES (?, ?, ?)`);
    stmt.run(user_id, 'Not Submitted', now);
    const id = this.db.query(`SELECT last_insert_rowid() as id`).get() as { id: number };
    return { id: id.id, user_id, status: 'Not Submitted', last_updated_ts: now };
  }

  listUsersWithStatus() {
    const sql = `
      SELECT u.id as user_id, u.name, u.email, u.org_role, u.is_admin, d.status, d.last_updated_ts
      FROM users u
      LEFT JOIN disclosures d ON d.user_id = u.id
      WHERE u.is_discloser = 1
      ORDER BY u.name ASC
    `;
    return this.db.query(sql).all() as any[];
  }

  getDisclosure(disclosure_id: number): Disclosure | null {
    const stmt = this.db.query(`SELECT * FROM disclosures WHERE id = ?`);
    const row = stmt.get(disclosure_id) as Disclosure | undefined;
    return row ?? null;
  }

  getDisclosureByUser(user_id: number): Disclosure | null {
    const stmt = this.db.query(`SELECT * FROM disclosures WHERE user_id = ?`);
    const row = stmt.get(user_id) as Disclosure | undefined;
    return row ?? null;
  }

  updateDisclosureStatus(id: number, status: string) {
    const now = this.nowISO();
    const stmt = this.db.prepare(`UPDATE disclosures SET status=?, last_updated_ts=? WHERE id=?`);
    stmt.run(status, now, id);
  }

  // --- Items ---
  getItems(disclosure_id: number): DisclosureItem[] {
    const stmt = this.db.query(`SELECT * FROM disclosure_items WHERE disclosure_id = ? ORDER BY id ASC`);
    return stmt.all(disclosure_id) as DisclosureItem[];
  }

  replaceItems(disclosure_id: number, items: Partial<DisclosureItem>[]) {
    // remove existing, then insert new
    this.db.prepare(`DELETE FROM disclosure_items WHERE disclosure_id = ?`).run(disclosure_id);
    const now = this.nowISO();
    const stmt = this.db.prepare(`
      INSERT INTO disclosure_items (
        disclosure_id, type, entity_name, role_title, is_primary_employment,
        ownership_ge_one_percent, contracting_entity, ultimate_funder, is_nda,
        sector_type, topic_area, over_threshold_10k, ip_type, ip_title, ip_application_number,
        url, description, created_at, updated_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    for (const it of items) {
      stmt.run(
        disclosure_id, it.type ?? null, it.entity_name ?? null, it.role_title ?? null, it.is_primary_employment ? 1 : 0,
        it.ownership_ge_one_percent ? 1 : 0,
        it.contracting_entity ?? null, it.ultimate_funder ?? null, it.is_nda ? 1 : 0,
        it.sector_type ?? null, it.topic_area ?? null, it.over_threshold_10k ? 1 : 0,
        it.ip_type ?? null, it.ip_title ?? null, it.ip_application_number ?? null,
        it.url ?? null, it.description ?? null, now, now
      )
    }
  }
}
