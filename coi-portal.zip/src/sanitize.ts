import type { DB, DisclosureItem, User } from './db';
import { slugify } from './utils';

export type PublicRow = {
  name: string;
  hl7_role: string;
  primary_employer: string;
  paid_governance_roles: string; // '; ' separated
  ownership_companies_1pct_plus: string; // '; ' separated
  ip_summary: string; // '; ' separated
  contracting_entities: string; // '; ' separated
  ultimate_funders_or_sector_topic: string; // '; ' separated
  last_updated: string;
  slug: string;
};

export function buildPublicRows(db: DB): PublicRow[] {
  const users = db.listUsersWithStatus();
  const rows: PublicRow[] = [];

  for (const u of users) {
    const d = db.getDisclosureByUser(u.user_id);
    if (!d) continue;

    const items = db.getItems(d.id);

    const employments = items.filter(i => i.type === 'employment');
    const primaryEmp = employments.find(i => i.is_primary_employment === 1) ?? employments[0];
    const primary_employer = primaryEmp?.entity_name ?? '';

    const rolesList = employments.map(i => {
      const role = i.role_title ? ` (${i.role_title})` : '';
      return `${i.entity_name ?? ''}${role}`.trim();
    }).filter(Boolean);

    const ownerships = items.filter(i => i.type === 'ownership' && i.ownership_ge_one_percent === 1);
    const ownership_companies = ownerships.map(i => i.entity_name ?? '').filter(Boolean);

    const ips = items.filter(i => i.type === 'ip');
    const ip_summary = ips.map(i => i.ip_title ?? i.url ?? '').filter(Boolean);

    const comps = items.filter(i => i.type === 'compensation' && i.over_threshold_10k === 1);
    const contracting = comps.map(i => i.contracting_entity ?? '').filter(Boolean);
    const ultimate = comps.map(i => {
      if (i.is_nda === 1) {
        const segs = [i.sector_type ?? 'NDA', i.topic_area ?? ''];
        return segs.filter(Boolean).join(': ');
      }
      return (i.ultimate_funder ?? i.contracting_entity ?? '');
    }).filter(Boolean);

    const row: PublicRow = {
      name: u.name,
      hl7_role: u.org_role,
      primary_employer,
      paid_governance_roles: rolesList.join('; '),
      ownership_companies_1pct_plus: ownership_companies.join('; '),
      ip_summary: ip_summary.join('; '),
      contracting_entities: contracting.join('; '),
      ultimate_funders_or_sector_topic: ultimate.join('; '),
      last_updated: d.last_updated_ts,
      slug: slugify(u.name)
    };
    rows.push(row);
  }

  return rows;
}

// CSV helpers (quote if necessary)
function csvEscape(s: string) {
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

export function toCSV(rows: PublicRow[]): string {
  const header = [
    'name','hl7_role','primary_employer','paid_governance_roles','ownership_companies_1pct_plus',
    'ip_summary','contracting_entities','ultimate_funders_or_sector_topic','last_updated','slug'
  ];
  const lines = [header.join(',')];
  for (const r of rows) {
    const vals = [
      r.name, r.hl7_role, r.primary_employer, r.paid_governance_roles, r.ownership_companies_1pct_plus,
      r.ip_summary, r.contracting_entities, r.ultimate_funders_or_sector_topic, r.last_updated, r.slug
    ].map(csvEscape);
    lines.push(vals.join(','));
  }
  return lines.join('\n') + '\n';
}
