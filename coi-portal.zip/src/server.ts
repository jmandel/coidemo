import { Elysia } from 'elysia';
import cookie from '@elysiajs/cookie';
import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { DB } from './db';
import { env, randomId } from './utils';
import { handleLoginRedirect, handleCallback } from './auth';
import { buildPublicRows, toCSV } from './sanitize';
import { generateStaticSiteFromCSV } from './static_site';

const PORT = Number(process.env.PORT ?? 3000);
const APP_BASE_URL = process.env.APP_BASE_URL ?? `http://localhost:${PORT}`;

const app = new Elysia().use(cookie()).state('db', new DB());

// Initialize DB & directories
app.onStart(({ store }) => {
  const db = store.db;
  db.init();
  if (!existsSync('./data')) mkdirSync('./data', { recursive: true });
  if (!existsSync('./public_site')) mkdirSync('./public_site', { recursive: true });
});

function requireAuth(ctx: any) {
  const sid = ctx.cookie?.sid;
  if (!sid) return null;
  const s = ctx.store.db.getSession(sid);
  if (!s) return null;
  const user = ctx.store.db.getUserById(s.user_id);
  return user;
}

function requireAdmin(ctx: any) {
  const u = requireAuth(ctx);
  if (!u || u.is_admin !== 1) return null;
  return u;
}

// Health
app.get('/health', () => ({ ok: true }));

// OIDC
app.get('/auth/login', async ({ set, cookie }) => {
  const { url, cookieValue } = await handleLoginRedirect(APP_BASE_URL);
  set.header['Location'] = url;
  // short-lived cookie for OIDC state
  cookie.set('oidc', cookieValue, { httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true', path: '/', maxAge: 600 });
  return new Response(null, { status: 302 });
});

app.get('/auth/callback', async ({ request, store, set, cookie }) => {
  const url = new URL(request.url);
  try {
    const user = await handleCallback(store.db, url.searchParams, cookie.get('oidc') ?? null);
    // Only allow users that are marked as disclosers (seeded beforehand)
    if (user.is_discloser !== 1) {
      return new Response('Not authorized (not in discloser cohort). Contact admin.', { status: 403 });
    }
    // create session
    const sid = randomId(24);
    const expires = new Date(Date.now() + 1000 * 60 * 60 * 24 * 7); // 7 days
    store.db.createSession(user.id, sid, expires.toISOString());
    cookie.set('sid', sid, { httpOnly: true, sameSite: 'lax', secure: process.env.COOKIE_SECURE === 'true', path: '/', maxAge: 60*60*24*7 });
    // redirect to app
    set.header['Location'] = '/';
    return new Response(null, { status: 302 });
  } catch (e) {
    console.error(e);
    return new Response('Authentication error', { status: 400 });
  }
});

app.get('/auth/logout', ({ cookie, store }) => {
  const sid = cookie.get('sid');
  if (sid) store.db.deleteSession(sid);
  cookie.remove('sid', { path: '/' });
  return new Response(null, { status: 204 });
});

// Current user
app.get('/api/me', ({ cookie, store }) => {
  const user = requireAuth({ cookie, store });
  if (!user) return new Response('Unauthorized', { status: 401 });
  const d = store.db.getDisclosureByUser(user.id) ?? store.db.getOrCreateDisclosureForUser(user.id);
  return { user, disclosure: d };
});

// Get disclosure (with items)
app.get('/api/disclosure', ({ cookie, store }) => {
  const user = requireAuth({ cookie, store });
  if (!user) return new Response('Unauthorized', { status: 401 });
  const d = store.db.getOrCreateDisclosureForUser(user.id);
  const items = store.db.getItems(d.id);
  return { disclosure: d, items };
});

// Update disclosure items (auto-save)
app.put('/api/disclosure', async ({ cookie, store, request }) => {
  const user = requireAuth({ cookie, store });
  if (!user) return new Response('Unauthorized', { status: 401 });
  const d = store.db.getOrCreateDisclosureForUser(user.id);
  const body = await request.json();
  if (!Array.isArray(body.items)) return new Response('Invalid payload', { status: 400 });
  store.db.replaceItems(d.id, body.items);
  store.db.updateDisclosureStatus(d.id, 'Updated');
  const items = store.db.getItems(d.id);
  return { ok: true, disclosure: store.db.getDisclosure(d.id), items };
});

// Submit disclosure
app.post('/api/disclosure/submit', ({ cookie, store }) => {
  const user = requireAuth({ cookie, store });
  if (!user) return new Response('Unauthorized', { status: 401 });
  const d = store.db.getOrCreateDisclosureForUser(user.id);
  store.db.updateDisclosureStatus(d.id, 'Submitted');
  return { ok: true };
});

// Admin: list disclosers
app.get('/api/admin/disclosers', ({ cookie, store }) => {
  const admin = requireAdmin({ cookie, store });
  if (!admin) return new Response('Forbidden', { status: 403 });
  const rows = store.db.listUsersWithStatus();
  return { disclosers: rows };
});

// Admin: view a user's disclosure
app.get('/api/admin/disclosures/:userId', ({ cookie, store, params }) => {
  const admin = requireAdmin({ cookie, store });
  if (!admin) return new Response('Forbidden', { status: 403 });
  const uid = Number(params.userId);
  const d = store.db.getDisclosureByUser(uid);
  if (!d) return { disclosure: null, items: [] };
  const items = store.db.getItems(d.id);
  return { disclosure: d, items };
});

// Admin: generate public report (returns CSV download and generates static site)
app.post('/api/admin/generate-public-report', async ({ cookie, store, set }) => {
  const admin = requireAdmin({ cookie, store });
  if (!admin) return new Response('Forbidden', { status: 403 });

  const rows = buildPublicRows(store.db);
  const csv = toCSV(rows);
  const csvPath = './public_disclosures.csv';
  writeFileSync(csvPath, csv, 'utf-8');

  // Also generate static site from CSV
  generateStaticSiteFromCSV(csv, './public_site');

  set.headers['Content-Type'] = 'text/csv; charset=utf-8';
  set.headers['Content-Disposition'] = 'attachment; filename="public_disclosures.csv"';
  return new Response(csv);
});

// Serve frontend (built assets)
app.get('/', async () => {
  const index = Bun.file('./frontend/dist/index.html');
  if (!await index.exists()) {
    return new Response('Frontend not built. Run: cd frontend && bun run build', { status: 500 });
  }
  return new Response(index);
});

app.get('/assets/*', async ({ request }) => {
  const url = new URL(request.url);
  const f = Bun.file(`.${url.pathname}`);
  if (!await f.exists()) return new Response('Not Found', { status: 404 });
  return new Response(f);
});

app.get('/public_site/*', async ({ request }) => {
  const url = new URL(request.url);
  const f = Bun.file(`.${url.pathname}`);
  if (!await f.exists()) return new Response('Not Found', { status: 404 });
  return new Response(f);
});

app.listen(PORT);
console.log(`COI portal running at ${APP_BASE_URL}`);
