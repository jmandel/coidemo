PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hl7_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  org_role TEXT NOT NULL,             -- Board, Officer, Exec, TSC, ProductDirector, ProgramChair, CoChair
  is_admin INTEGER NOT NULL DEFAULT 0,
  is_discloser INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL UNIQUE,
  user_id INTEGER NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS disclosures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'Not Submitted', -- Not Submitted | Submitted | Updated
  last_updated_ts TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS disclosure_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  disclosure_id INTEGER NOT NULL,
  type TEXT NOT NULL,                      -- employment | ownership | compensation | travel_gift | ip
  entity_name TEXT,                        -- generic field, used for employment/org or ownership company
  role_title TEXT,                         -- for employment/governance roles
  is_primary_employment INTEGER DEFAULT 0, -- for primary employer/affiliation
  ownership_ge_one_percent INTEGER DEFAULT 0, -- 1%+ ownership flag

  -- compensation & funding clarity
  contracting_entity TEXT,
  ultimate_funder TEXT,
  is_nda INTEGER DEFAULT 0,
  sector_type TEXT,
  topic_area TEXT,
  over_threshold_10k INTEGER DEFAULT 0,

  -- IP details
  ip_type TEXT,
  ip_title TEXT,
  ip_application_number TEXT,
  url TEXT,

  description TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (disclosure_id) REFERENCES disclosures(id) ON DELETE CASCADE
);
