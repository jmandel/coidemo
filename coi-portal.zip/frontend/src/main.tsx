import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link, useNavigate, useParams } from 'react-router-dom'
import './styles.css'

function useMe() {
  const [data, setData] = React.useState<any>(null)
  React.useEffect(() => {
    fetch('/api/me').then(async r => {
      if (r.status === 401) { setData({ user: null }); return; }
      setData(await r.json())
    })
  }, [])
  return data
}

function Nav() {
  return (
    <header>
      <div className="container" style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <nav>
          <Link to="/">Home</Link>
          <Link to="/form">Disclosure Form</Link>
          <Link to="/admin">Admin</Link>
        </nav>
        <nav>
          <a href="/auth/login">Login</a>
          <a href="/auth/logout">Logout</a>
        </nav>
      </div>
    </header>
  )
}

function Home() {
  const me = useMe()
  return (
    <div className="container">
      <div className="card">
        <h1>HL7 COI Disclosure Portal</h1>
        <p>Use your HL7 account to log in and complete your annual disclosure. Admins can generate a public report and static site.</p>
        <p className="small">Note: This portal collects relationships only—no dollar amounts or household details. NDA-restricted sponsors appear by sector and topic only.</p>
      </div>
      {me?.user && (
        <div className="card">
          <h2>Welcome, {me.user.name}</h2>
          <div className="small">Role: {me.user.org_role} · {me.user.is_admin ? 'Admin' : 'Discloser'}</div>
        </div>
      )}
    </div>
  )
}

// ---- Repeatable List Components ----
function ListControls({ title, items, setItems, renderItem, newItem }: any) {
  function add() { setItems([...items, newItem()]) }
  function remove(idx: number) { setItems(items.filter((_: any, i: number) => i !== idx)) }
  return (
    <div className="card">
      <div className="listHeader">
        <h2>{title}</h2>
        <button onClick={add}>Add</button>
      </div>
      {items.map((it: any, idx: number) => (
        <div key={idx} className="listItem">
          {renderItem(it, (v: any) => {
            const copy = [...items]
            copy[idx] = { ...copy[idx], ...v }
            setItems(copy)
          })}
          <div style={{textAlign:'right'}}><button onClick={() => remove(idx)}>Remove</button></div>
        </div>
      ))}
      {items.length === 0 && <div className="small">No entries yet.</div>}
    </div>
  )
}

function DisclosureForm() {
  const [loading, setLoading] = React.useState(true)
  const [disclosure, setDisclosure] = React.useState<any>(null)
  const [items, setItems] = React.useState<any[]>([])
  const [saving, setSaving] = React.useState(false)
  const [saveMsg, setSaveMsg] = React.useState('')

  React.useEffect(() => {
    fetch('/api/disclosure').then(async r => {
      if (r.status === 401) { alert('Please login'); window.location.href='/auth/login'; return; }
      const data = await r.json()
      setDisclosure(data.disclosure); setItems(data.items); setLoading(false)
    })
  }, [])

  // Auto-save (debounced)
  const debounceRef = React.useRef<any>(null)
  React.useEffect(() => {
    if (loading) return;
    setSaving(true)
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(async () => {
      const res = await fetch('/api/disclosure', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items })
      })
      const js = await res.json()
      setSaving(false)
      setSaveMsg('Saved ' + new Date().toLocaleTimeString())
      setDisclosure(js.disclosure)
    }, 800)
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current) }
  }, [items])

  async function submit() {
    const r = await fetch('/api/disclosure/submit', { method: 'POST' })
    if (r.ok) {
      alert('Disclosure submitted.')
      const me = await (await fetch('/api/disclosure')).json()
      setDisclosure(me.disclosure)
    }
  }

  function byType(t: string) { return items.filter(i => i.type === t) }
  function setByType(t: string, data: any[]) {
    const others = items.filter(i => i.type !== t)
    setItems([...others, ...data.map(x => ({ ...x, type: t }))])
  }

  if (loading) return <div className="container"><div className="card">Loading...</div></div>

  return (
    <div className="container">
      <div className="card">
        <h1>Disclosure Form</h1>
        <div className="small">Status: {disclosure.status} · Last updated: {new Date(disclosure.last_updated_ts).toLocaleString()} · {saving ? 'Saving...' : saveMsg}</div>
      </div>

      <ListControls title="Employment & Governance Roles"
        items={byType('employment')}
        setItems={(v: any[]) => setByType('employment', v)}
        newItem={() => ({ entity_name: '', role_title: '', is_primary_employment: 0, description: '' })}
        renderItem={(it: any, patch: any) => (
          <div className="row">
            <div className="col-6">
              <label>Organization</label>
              <input value={it.entity_name||''} onChange={e=>patch({entity_name:e.target.value})} />
            </div>
            <div className="col-6">
              <label>Role/Title</label>
              <input value={it.role_title||''} onChange={e=>patch({role_title:e.target.value})} />
            </div>
            <div className="col-12">
              <label><input type="checkbox" checked={!!it.is_primary_employment} onChange={e=>patch({is_primary_employment: e.target.checked?1:0})} /> Primary employer/affiliation</label>
            </div>
            <div className="col-12">
              <label>Description (optional)</label>
              <input value={it.description||''} onChange={e=>patch({description:e.target.value})} />
            </div>
          </div>
        )}
      />

      <ListControls title="Ownership Interests (≥1% equity)"
        items={byType('ownership')}
        setItems={(v: any[]) => setByType('ownership', v)}
        newItem={() => ({ entity_name: '', ownership_ge_one_percent: 1 })}
        renderItem={(it: any, patch: any) => (
          <div className="row">
            <div className="col-12">
              <label>Company name</label>
              <input value={it.entity_name||''} onChange={e=>patch({entity_name:e.target.value})} />
            </div>
            <div className="col-12 small">
              Threshold: disclosure is required for holdings of 1% or more (public or private).
            </div>
          </div>
        )}
      />

      <ListControls title="Compensation (≥$10,000 per entity; include intermediated funding)"
        items={byType('compensation')}
        setItems={(v: any[]) => setByType('compensation', v)}
        newItem={() => ({ contracting_entity: '', ultimate_funder: '', is_nda: 0, sector_type: '', topic_area: '', over_threshold_10k: 1 })}
        renderItem={(it: any, patch: any) => (
          <div className="row">
            <div className="col-6">
              <label>Contracting entity (who pays you)</label>
              <input value={it.contracting_entity||''} onChange={e=>patch({contracting_entity:e.target.value})} />
            </div>
            <div className="col-6">
              <label>Ultimate funder/sponsor (if known)</label>
              <input value={it.ultimate_funder||''} onChange={e=>patch({ultimate_funder:e.target.value})} />
            </div>
            <div className="col-6">
              <label>NDA-restricted?</label>
              <select value={it.is_nda?1:0} onChange={e=>patch({is_nda: Number(e.target.value)})}>
                <option value={0}>No</option>
                <option value={1}>Yes</option>
              </select>
            </div>
            <div className="col-6">
              <label>Sector/agency type (if NDA)</label>
              <input value={it.sector_type||''} onChange={e=>patch({sector_type:e.target.value})} />
            </div>
            <div className="col-12">
              <label>General topic area (if NDA)</label>
              <input value={it.topic_area||''} onChange={e=>patch({topic_area:e.target.value})} />
            </div>
            <div className="col-12">
              <label><input type="checkbox" checked={!!it.over_threshold_10k} onChange={e=>patch({over_threshold_10k: e.target.checked?1:0})} /> Meets ≥ $10,000 threshold (past 12 months)</label>
            </div>
          </div>
        )}
      />

      <ListControls title="Sponsored Travel & Significant Gifts (≥$10,000 per source)"
        items={byType('travel_gift')}
        setItems={(v: any[]) => setByType('travel_gift', v)}
        newItem={() => ({ entity_name: '', description: '', over_threshold_10k: 1 })}
        renderItem={(it: any, patch: any) => (
          <div className="row">
            <div className="col-6">
              <label>Source</label>
              <input value={it.entity_name||''} onChange={e=>patch({entity_name:e.target.value})} />
            </div>
            <div className="col-6">
              <label>Description</label>
              <input value={it.description||''} onChange={e=>patch({description:e.target.value})} />
            </div>
            <div className="col-12">
              <label><input type="checkbox" checked={!!it.over_threshold_10k} onChange={e=>patch({over_threshold_10k: e.target.checked?1:0})} /> Meets ≥ $10,000 threshold (per calendar year)</label>
            </div>
          </div>
        )}
      />

      <ListControls title="Intellectual Property (material to HL7)"
        items={byType('ip')}
        setItems={(v: any[]) => setByType('ip', v)}
        newItem={() => ({ ip_type: 'patent', ip_title: '', url: '' })}
        renderItem={(it: any, patch: any) => (
          <div className="row">
            <div className="col-6">
              <label>Type</label>
              <select value={it.ip_type||'patent'} onChange={e=>patch({ip_type:e.target.value})}>
                <option value="patent">Patent</option>
                <option value="copyright">Copyright</option>
                <option value="trademark">Trademark</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="col-6">
              <label>Title / Identifier</label>
              <input value={it.ip_title||''} onChange={e=>patch({ip_title:e.target.value})} />
            </div>
            <div className="col-12">
              <label>URL (optional)</label>
              <input value={it.url||''} onChange={e=>patch({url:e.target.value})} />
            </div>
          </div>
        )}
      />

      <div className="card" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div className="small">Auto-saves while you type.</div>
        <button className="primary" onClick={submit}>Submit</button>
      </div>
    </div>
  )
}

function Admin() {
  const [rows, setRows] = React.useState<any[]>([])
  const [loading, setLoading] = React.useState(true)

  React.useEffect(() => {
    fetch('/api/admin/disclosers').then(async r => {
      if (r.status === 403) { alert('Admins only'); return; }
      const js = await r.json(); setRows(js.disclosers); setLoading(false)
    })
  }, [])

  async function generateReport() {
    const res = await fetch('/api/admin/generate-public-report', { method: 'POST' })
    if (!res.ok) { alert('Failed'); return }
    // Trigger download
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'public_disclosures.csv'
    a.click()
    URL.revokeObjectURL(url)
    alert('Generated CSV and static site at /public_site (server filesystem).')
  }

  return (
    <div className="container">
      <div className="card" style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>Administrator Dashboard</h1>
        <button className="primary" onClick={generateReport}>Generate Public Report</button>
      </div>
      {loading ? <div className="card">Loading...</div> : (
        <div className="card">
          <table>
            <thead>
              <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last Updated</th><th></th></tr>
            </thead>
            <tbody>
              {rows.map((r: any) => (
                <tr key={r.user_id}>
                  <td>{r.name}</td>
                  <td>{r.email}</td>
                  <td>{r.org_role}</td>
                  <td>{r.status||'Not Submitted'}</td>
                  <td>{r.last_updated_ts||'-'}</td>
                  <td><Link to={`/admin/user/${r.user_id}`}>View</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

function AdminUser() {
  const { userId } = useParams()
  const [d, setD] = React.useState<any>(null)
  React.useEffect(() => {
    fetch(`/api/admin/disclosures/${userId}`).then(async r => setD(await r.json()))
  }, [userId])

  if (!d) return <div className="container"><div className="card">Loading...</div></div>

  const sections = ['employment','ownership','compensation','travel_gift','ip']
  return (
    <div className="container">
      <div className="card">
        <h1>Disclosure Details</h1>
      </div>
      {sections.map((t) => {
        const items = (d.items||[]).filter((i:any)=>i.type===t)
        return (
          <div className="card" key={t}>
            <h2>{t}</h2>
            {items.length===0 ? <div className="small">None</div> : (
              <pre style={{whiteSpace:'pre-wrap'}}>{JSON.stringify(items, null, 2)}</pre>
            )}
          </div>
        )
      })}
    </div>
  )
}

function App() {
  return (
    <BrowserRouter>
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/form" element={<DisclosureForm />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="/admin/user/:userId" element={<AdminUser />} />
      </Routes>
    </BrowserRouter>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
